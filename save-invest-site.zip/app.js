// Save & Invest — simple calculators (no tracking)
// Utility formatters
const $ = (sel) => document.querySelector(sel);
const fmt = new Intl.NumberFormat(undefined, { style: 'currency', currency: guessCurrency() });
function guessCurrency(){
  try{
    const locale = navigator.language || 'en-US';
    // Quick map based on locale country (very rough)
    if (locale.endsWith('GB')) return 'GBP';
    if (locale.endsWith('EU') || locale.endsWith('DE') || locale.endsWith('FR') || locale.endsWith('IT') || locale.endsWith('ES')) return 'EUR';
    if (locale.endsWith('IN')) return 'INR';
    if (locale.endsWith('AU')) return 'AUD';
    if (locale.endsWith('CA')) return 'CAD';
    return 'USD';
  }catch{ return 'USD'; }
}

// Compound interest with monthly compounding and contributions
function compoundWithMonthly({principal, monthly, annualRatePct, years}){
  const r = (annualRatePct/100) / 12;
  const n = Math.max(0, Math.floor(years*12));
  let balance = principal;
  const labels = [];
  const series = [];
  let totalContrib = principal;
  for(let m=1; m<=n; m++){
    balance = balance*(1+r) + monthly;
    totalContrib += monthly;
    if (m % 12 === 0){
      labels.push(String(m/12));
      series.push(balance);
    }
  }
  const interest = Math.max(0, balance - totalContrib);
  return { balance, totalContrib, interest, labels, series };
}

// Required monthly contribution to hit target with monthly compounding
function requiredMonthlyForTarget({principal=0, target, annualRatePct=0, years}){
  const i = (annualRatePct/100) / 12;
  const n = Math.max(1, Math.floor(years*12));
  if (i === 0){
    const needed = Math.max(0, target - principal);
    return needed / n;
  }
  const growthPrincipal = principal * Math.pow(1+i, n);
  const remaining = Math.max(0, target - growthPrincipal);
  // annuity due (end of period): PMT = i * FV / ((1+i)^n - 1)
  return remaining * i / (Math.pow(1+i, n) - 1);
}

// State helpers
const store = {
  get key(){ return 'saveinvest.v1'; },
  read(){
    try{ return JSON.parse(localStorage.getItem(this.key) || '{}'); }catch{ return {}; }
  },
  write(data){
    localStorage.setItem(this.key, JSON.stringify(data));
  }
};

// Charts (Chart.js)
let svChart, ivChart;
function renderLineChart(ctx, labels, data, label){
  if (!ctx) return;
  if (ctx === $('#sv-chart') && svChart){ svChart.destroy(); }
  if (ctx === $('#iv-chart') && ivChart){ ivChart.destroy(); }
  const c = new Chart(ctx, {
    type: 'line',
    data: { labels, datasets: [{ label, data, tension: .25, borderWidth: 2, pointRadius: 0, fill: true }]},
    options: {
      responsive: true, maintainAspectRatio: false,
      scales: { x: { title: { display: true, text: 'Years'} }, y: { beginAtZero: true } },
      plugins: { legend: { display: false }, tooltip: { mode: 'index', intersect: false } }
    }
  });
  if (ctx === $('#sv-chart')) svChart = c;
  if (ctx === $('#iv-chart')) ivChart = c;
}

// Savings form behavior
function initSavings(){
  const form = $('#savingsForm');
  const inputs = ['#sv-principal','#sv-monthly','#sv-rate','#sv-years'].map((s)=>$(s));
  function calc(){
    const [principalEl, monthlyEl, rateEl, yearsEl] = inputs;
    const vals = {
      principal: Number(principalEl.value || 0),
      monthly: Number(monthlyEl.value || 0),
      annualRatePct: Number(rateEl.value || 0),
      years: Number(yearsEl.value || 0)
    };
    const out = compoundWithMonthly(vals);
    $('#sv-final').textContent = fmt.format(out.balance);
    $('#sv-contrib').textContent = fmt.format(out.totalContrib);
    $('#sv-interest').textContent = fmt.format(out.interest);
    renderLineChart($('#sv-chart'), out.labels, out.series, 'Savings');
    // persist
    const data = store.read(); data.savings = vals; store.write(data);
  }
  form.addEventListener('submit', (e)=>{ e.preventDefault(); calc(); });
  $('#sv-reset').addEventListener('click', ()=>{
    inputs.forEach(i=>i.value = i.id === 'sv-rate' ? 3.5 : (i.id === 'sv-monthly' ? 200 : (i.id==='sv-years'?10:1000)));
    calc();
  });
  // autocalc on load with persisted values
  const saved = store.read().savings;
  if (saved){
    $('#sv-principal').value = saved.principal;
    $('#sv-monthly').value = saved.monthly;
    $('#sv-rate').value = saved.annualRatePct;
    $('#sv-years').value = saved.years;
  }
  calc();
}

// Investing form
function initInvesting(){
  const form = $('#investForm');
  const inputs = ['#iv-principal','#iv-monthly','#iv-rate','#iv-years'].map((s)=>$(s));
  function calc(){
    const [principalEl, monthlyEl, rateEl, yearsEl] = inputs;
    const vals = {
      principal: Number(principalEl.value || 0),
      monthly: Number(monthlyEl.value || 0),
      annualRatePct: Number(rateEl.value || 0),
      years: Number(yearsEl.value || 0)
    };
    const out = compoundWithMonthly(vals);
    $('#iv-final').textContent = fmt.format(out.balance);
    $('#iv-contrib').textContent = fmt.format(out.totalContrib);
    $('#iv-growth').textContent = fmt.format(Math.max(0, out.balance - out.totalContrib));
    renderLineChart($('#iv-chart'), out.labels, out.series, 'Investing');
    const data = store.read(); data.investing = vals; store.write(data);
  }
  form.addEventListener('submit', (e)=>{ e.preventDefault(); calc(); });
  $('#iv-reset').addEventListener('click', ()=>{
    inputs.forEach(i=>i.value = i.id==='iv-rate'?7:(i.id==='iv-monthly'?300:(i.id==='iv-years'?15:0)));
    calc();
  });
  const saved = store.read().investing;
  if (saved){
    $('#iv-principal').value = saved.principal;
    $('#iv-monthly').value = saved.monthly;
    $('#iv-rate').value = saved.annualRatePct;
    $('#iv-years').value = saved.years;
  }
  calc();
}

// Goals
function initGoals(){
  const form = $('#goalForm');
  const list = $('#goalsList');
  function render(){
    const data = store.read();
    const goals = data.goals || [];
    list.innerHTML = '';
    if (goals.length === 0){
      const empty = document.createElement('div');
      empty.className = 'muted';
      empty.textContent = 'No goals yet — add one above.';
      list.appendChild(empty);
      return;
    }
    goals.forEach((g, idx)=>{
      const item = document.createElement('div');
      item.className = 'goal';
      const monthly = requiredMonthlyForTarget({ principal:0, target:g.target, annualRatePct:g.rate, years:g.years });
      item.innerHTML = `
        <div class="meta">
          <span class="name">${escapeHtml(g.name)}</span>
          <span class="desc">Target ${fmt.format(g.target)} in ${g.years} year(s) at ${g.rate}% ⇒ <strong>${fmt.format(monthly)}</strong> / mo</span>
        </div>
        <div class="actions">
          <button class="button" data-action="dup" data-idx="${idx}" aria-label="Duplicate goal">Duplicate</button>
          <button class="button" data-action="del" data-idx="${idx}" aria-label="Delete goal">Delete</button>
        </div>`;
      list.appendChild(item);
    });
  }
  function addGoal(g){
    const data = store.read();
    const goals = data.goals || [];
    goals.push(g);
    data.goals = goals; store.write(data); render();
  }
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const g = {
      name: $('#gl-name').value.trim() || 'Goal',
      target: Number($('#gl-target').value || 0),
      years: Number($('#gl-years').value || 1),
      rate: Number($('#gl-rate').value || 0)
    };
    addGoal(g);
    form.reset();
    $('#gl-target').value = 20000; $('#gl-years').value = 5; $('#gl-rate').value = 4;
  });
  $('#goalsList').addEventListener('click', (e)=>{
    const btn = e.target.closest('button'); if (!btn) return;
    const idx = Number(btn.dataset.idx);
    const data = store.read();
    const goals = data.goals || [];
    if (btn.dataset.action === 'del'){
      goals.splice(idx,1);
    } else if (btn.dataset.action === 'dup'){
      goals.splice(idx+1, 0, {...goals[idx]});
    }
    data.goals = goals; store.write(data); render();
  });
  render();
}

// Emergency fund
function initEmergency(){
  const form = $('#efForm');
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const expenses = Number($('#ef-expenses').value || 0);
    const months = Number($('#ef-months').value || 0);
    const total = expenses * months;
    $('#ef-total').textContent = fmt.format(total);
    const data = store.read(); data.emergency = { expenses, months }; store.write(data);
  });
  const saved = store.read().emergency;
  if (saved){
    $('#ef-expenses').value = saved.expenses;
    $('#ef-months').value = saved.months;
  }
}

// Accessibility & helpers
function escapeHtml(s){ return s.replace(/[&<>"']/g, (c)=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' }[c])); }

// Theme toggle
function initTheme(){
  const btn = $('#themeToggle');
  const data = store.read();
  if (data.theme === 'light'){ document.documentElement.classList.add('light'); }
  btn.addEventListener('click', ()=>{
    document.documentElement.classList.toggle('light');
    const mode = document.documentElement.classList.contains('light') ? 'light' : 'dark';
    const d = store.read(); d.theme = mode; store.write(d);
  });
}

// Footer year
function initYear(){ $('#year').textContent = new Date().getFullYear(); }

// Init all
addEventListener('DOMContentLoaded', ()=>{
  initTheme();
  initYear();
  initSavings();
  initInvesting();
  initGoals();
  initEmergency();
});
