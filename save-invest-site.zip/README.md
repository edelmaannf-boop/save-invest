# Save & Invest — Static Site

A modern, responsive static website with calculators for:
- **Savings (compound interest)**
- **Investing (DCA/SIP)**
- **Goal planner** with required monthly contributions
- **Emergency fund**

No backend, no tracking. Charts via Chart.js CDN.

## Run locally
Just open `index.html` in your browser. (Double‑click or drag into a tab.)

## Deploy to GitHub Pages (web UI — easiest)
1. Go to <https://github.com> and create a **new repository** (e.g., `save-invest`).
2. On your new repo page, click **Add file ▸ Upload files**.
3. **Upload** these files: `index.html`, `styles.css`, `app.js`, `README.md`.
4. Commit the changes (click **Commit changes**).
5. Go to **Settings ▸ Pages**.
   - Under **Build and deployment**, set **Source** to **Deploy from a branch**.
   - Set **Branch** to **main** and **/ (root)**, then click **Save**.
6. Wait a minute, then visit the URL shown on that page (something like `https://<your-username>.github.io/save-invest/`).

## Deploy to GitHub Pages (command line)
```bash
# 1) Create repo locally
mkdir save-invest && cd save-invest
# Copy your files into this folder

git init
git add .
git commit -m "Initial commit: Save & Invest site"

# 2) Create remote repo on GitHub (via web) and copy its URL, e.g.:
git remote add origin https://github.com/<your-username>/save-invest.git
git branch -M main
git push -u origin main

# 3) Enable GitHub Pages
# On GitHub: Settings ▸ Pages ▸ Source: Deploy from a branch ▸ Branch: main / root
```

### Update the site later
- Edit files (`index.html`, `styles.css`, `app.js`) and commit/push to `main`. Pages will auto‑redeploy.

### Custom domain (optional)
1. Buy a domain from your registrar.
2. In **Settings ▸ Pages**, add your custom domain.
3. At your registrar, create **A** records pointing to GitHub Pages IPs, or a **CNAME** to `<username>.github.io`.
4. In the repo root, GitHub will create a `CNAME` file; keep it committed.

## Notes
- This is **educational only**. Investment returns are estimates; fees/taxes not included.
- If charts do not render offline, ensure you are connected to the Internet (Chart.js is loaded via CDN).
